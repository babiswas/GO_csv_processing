package CSV_write_util

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
)

func CreateWriter(file_ptr *os.File) *csv.Writer {
	log.Println("Creating a writer.")
	writer := csv.NewWriter(file_ptr)
	return writer
}

func WriteCSVLinewise(writer *csv.Writer, records [][]string) bool {
	defer writer.Flush()
	message := ""
	for _, record := range records {
		if err := writer.Write(record); err != nil {
			message = fmt.Sprintf("Error occured %s", err)
			log.Fatal(message)
			break
		}
	}
	return true
}

func WriteCSVAll(writer *csv.Writer, records [][]string) bool {
	defer writer.Flush()
	message := ""
	if err := writer.WriteAll(records); err != nil {
		message = fmt.Sprintf("Error occured %s", err)
		log.Fatal(message)
		os.Exit(1)
	}
	return true
}
