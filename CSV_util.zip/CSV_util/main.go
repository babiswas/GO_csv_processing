package main

import (
	"CSV_util/CSV_read_util"
	"CSV_util/CSV_write_util"
	"CSV_util/RecordModel"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"sync"
)

func main() {
	var wg sync.WaitGroup
	file_name_parser := flag.String("file_name", "mynew.csv", "a string")
	flag.Parse()
	log.Println("Extracting filename from command line parser.")
	file_name := *file_name_parser
	message := ""
	log.Println("Creating a file pointer.")
	file_ptr, err := os.Open(file_name)
	if err != nil {
		message = fmt.Sprintf("Error occured %s", err)
		log.Fatal(message)
		os.Exit(1)
	}
	defer file_ptr.Close()
	log.Println("Creating a reader.")
	reader := CSV_read_util.CreateReader(file_ptr)

	fmt.Println("================== Processing Full content ====================")
	log.Println("Attempting to process full content of the file.")
	content := CSV_read_util.ProcessFullContent(reader)
	fmt.Println(content)
	fmt.Println("=================================================================")
	fmt.Println("=============== Processing line by line ==========================")
	_, err = file_ptr.Seek(0, io.SeekStart)
	reader = CSV_read_util.CreateReader(file_ptr)
	log.Println("Attempting to read the file line by line.")
	CSV_read_util.ProcessCSVLinewise(reader)
	fmt.Println("====================================================================")
	fmt.Println("=============== Process using go channel ===========================")
	chn := make(chan []string, 4)
	_, err = file_ptr.Seek(0, io.SeekStart)
	reader = CSV_read_util.CreateReader(file_ptr)
	log.Println("Attempting to read the file line by line through a channel.")
	wg.Add(1)
	go CSV_read_util.ProcessCSVLinewiseChannel(reader, chn, &wg)
	for val := range chn {
		fmt.Println(val)
	}
	wg.Wait()
	fmt.Scanln("Enter some string:")
	fmt.Println("============================= Write records in CSV ========================================")
	s1 := RecordModel.Student{Name: "Bapan1", Mark: 12, Roll: 21}
	s2 := RecordModel.Student{Name: "Bapan2", Mark: 13, Roll: 22}
	s3 := RecordModel.Student{Name: "Bapan3", Mark: 14, Roll: 23}
	all_student_record := []RecordModel.Student{s1, s2, s3}
	fmt.Println(all_student_record)
	records := RecordModel.Process_all_records(all_student_record)
	file_ptr, err = os.Create("file.csv")
	if err != nil {
		message = fmt.Sprintf("Error occured %s", err)
		log.Fatal(message)
		os.Exit(1)
	}
	defer file_ptr.Close()
	csv_writer := CSV_write_util.CreateWriter(file_ptr)
	status := CSV_write_util.WriteCSVLinewise(csv_writer, records)
	if status == true {
		fmt.Println("Sucessfully created the csv.")
	} else {
		fmt.Println("CSV creation failed.")
	}
}
