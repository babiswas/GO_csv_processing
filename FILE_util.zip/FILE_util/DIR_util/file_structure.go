package DIR_util

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
)

type MyFileInfo struct {
	Name  string `json:"name"`
	Size  int64  `json:"size"`
	IsDir bool   `json:"isdir"`
}

func (fl MyFileInfo) get_file_details_json() string {
	message := ""
	log.Println("Converting file info structure to json.")
	data, err := json.Marshal(fl)
	if err != nil {
		message = fmt.Sprintf("Error occured %s", err)
		log.Fatal(message)
		os.Exit(1)
	}
	log.Println("Returning file data to json string.")
	return string(data)
}

func process_all_file_infos(infos []MyFileInfo) []string {
	myfile_data := []string{}
	log.Println("Processing all the file infos.")
	for _, file_obj := range infos {
		myfile_data = append(myfile_data, file_obj.get_file_details_json())
	}
	return myfile_data
}
